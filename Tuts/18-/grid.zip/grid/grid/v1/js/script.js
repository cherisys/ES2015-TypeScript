﻿const PAGESIZEARRAY = ["10", "25", "50", "100"];

var type = {
    text: 1,
    data: 2,
    template: 3,
    action: 4
};
var DEFAULT_PAGINGCONFIGURATION = {
    sizePicker: false,
    pageSize: 10,
    pageNumber: 1
}


var defaults = {
    enableSearching: true,
    enablePaging: true,
    enableSorting: true,
    sortColumns: "id",
    culture: "en",
    theme: "",
    paging: DEFAULT_PAGINGCONFIGURATION
};


(function ($) {

    $.fn.adekTable = function (config) {
        var config = $.extend({}, defaults, config);

        let adektable = $(this);

        $(adektable).adekTableContainer(config);

        $(adektable).adekTableHeader(config);

        adekTableDataColumn(adektable, config, 0, 0, 0, 0, 0);

        $(adektable).adekTableTabs(config);

        adektable.find("#ddlPageSize").change(function () {
            adekTableDataColumn(adektable, config, 0, $('option:selected', $(this)).text(), $('option:selected', $(adektable.find("#ddlsortcolumns"))).val(), 0, $("#searchbox").val());
        });

        adektable.find("#ddlsortcolumns").change(function () {
            adekTableDataColumn(adektable, config, 0, $('option:selected', $(adektable.find("#ddlPageSize"))).val(), $('option:selected', $(this)).text(), 0, $("#searchbox").val());
        });

        adektable.find("#searchbox").keyup(function () {
            var textValue = $(this).val();
            adekTableDataColumn(adektable, config, 0, $('option:selected', $(adektable.find("#ddlPageSize"))).val(), $('option:selected', $(adektable.find("#ddlsortcolumns"))).val(), 0, textValue);
        });

    }

    $.fn.adekTableContainer = function (config) {

        let adektable = $(this);
        let tableContainer = document.createElement("div");
        tableContainer.className = "container";
        if (config.culture == "ar") {
            tableContainer.setAttribute("style", "direction:rtl !important");
        }
        $(this).prepend(tableContainer);
        let tableContainerrow = document.createElement("div");
        tableContainerrow.className = "row";
        tableContainer.appendChild(tableContainerrow);
        let tableContainerrowCol = document.createElement("div");
        tableContainerrowCol.className = "col-12";
        tableContainerrowCol.id = "mainDiv";
        tableContainerrow.appendChild(tableContainerrowCol);


        let tableSearching = document.createElement("div");
        tableSearching.className = "row";
        tableSearching.id = "txtsearching";
        tableContainerrowCol.appendChild(tableSearching);
        let tableSearchingCol = document.createElement("div");
        tableSearchingCol.className = "col-md-3";
        tableSearching.appendChild(tableSearchingCol);

        let divInputGroup = document.createElement("div");
        divInputGroup.className = "input-group";
        tableSearchingCol.appendChild(divInputGroup);
        let divprepend = document.createElement("div");
        divprepend.className = "input-group-prepend";

        divInputGroup.appendChild(divprepend);

        let tableShow = document.createElement("label");
        tableShow.innerText = "Show ";
        tableShow.className = "input-show-text";
        divprepend.appendChild(tableShow);
        let select = document.createElement("select");
        select.id = "ddlPageSize";
        select.className = "form-control";
        tableShow.appendChild(select);

        let tableEntry = document.createElement("label");
        tableEntry.innerText = "entries";
        tableEntry.className = "label-entries";
        divprepend.append(tableEntry);        
        $(PAGESIZEARRAY).each(function (index, value)
        {
            $(adektable).find("#ddlPageSize").append('<option id="' + value + '">' + value + '</option>')
        });
        if (config.enableSorting) {
            var searchingdiv = $(this).find("#txtsearching");
            let SearchingdivCol = document.createElement("div");
            SearchingdivCol.className = "col-md-3 offset-md-3 col-xs-6";
            searchingdiv.append(SearchingdivCol);
            let select = document.createElement("select");
            select.className = "form-control";
            select.id = "ddlsortcolumns";
            select.innerHTML = "<option value='0'>Select Sort Column</option>";
            SearchingdivCol.append(select);
            $(config.columns).each(function (index, value) {
                if (value.isSortable == true)
                    $(adektable).find("#ddlsortcolumns").append('<option id="' + value.name + '">' + value.name + '</option>')
            });
        }
        if (config.enableSearching) {
            var searchingdiv = $(this).find("#txtsearching");
            let SearchingdivCol = document.createElement("div");
            SearchingdivCol.className = "col-sm-12 col-md-3";
            searchingdiv.append(SearchingdivCol);
            let tableSearchinginputgroup = document.createElement("div");
            tableSearchinginputgroup.className = "input-group";
            SearchingdivCol.appendChild(tableSearchinginputgroup);
            let tableSearchinginputgroupprepend = document.createElement("div");
            tableSearchinginputgroupprepend.className = "input-group-prepend";
            tableSearchinginputgroupprepend.innerHTML = "<input type='text' class='form-control' id='searchbox' placeholder='Enter you search term' aria-label='Input group example' aria-describedby='btnGroupAddon2'>";
            tableSearchinginputgroup.appendChild(tableSearchinginputgroupprepend);
            let tableSearchinginputgrouptext = document.createElement("div");
            tableSearchinginputgrouptext.className = "input-group-text";
            tableSearchinginputgrouptext.id = "btnGroupAddon2";
            tableSearchinginputgrouptext.innerHTML = "<i class='fa fa-search'></i>"
            tableSearchinginputgroupprepend.appendChild(tableSearchinginputgrouptext);
        }



        let tableadektable = document.createElement("div");
        tableadektable.className = "adek-table";
        tableContainerrowCol.appendChild(tableadektable);
    }

    $.fn.adekTableHeader = function (config) {
        let tableheading = $(this).find(".adek-table");

        let tablerowadektablehead = document.createElement("div");
        tablerowadektablehead.className = "row adek-table-head";
        tableheading.prepend(tablerowadektablehead);


        var columns = config.columns;
        for (var i = 0; i < columns.length; i++)
        {
            if (columns[i].IsHidden == undefined || columns[i].IsHidden == false) {
                let col = document.createElement("div");
                col.className = columns[i].class;
                col.innerHTML = columns[i].name
                tablerowadektablehead.appendChild(col);
            }
        }
    }

    $.fn.adekTableTabs = function (config) {

        if (config.tabs != undefined) {
            let rowdetail = document.createElement("div");
            rowdetail.className = "row-detail w-100 d-none";
            $(this).prepend(rowdetail);
            let tabcontent = document.createElement("div");
            tabcontent.className = "tab-content";
            tabcontent.id = "myTabContent";
            rowdetail.appendChild(tabcontent);
            let navtabs = document.createElement("ul");
            navtabs.className = "nav nav-tabs";
            navtabs.id = "row-detail-tabls";
            navtabs.setAttribute("role", "tablist");
            var tabs = config.tabs;
            for (var i = 0; i < tabs.length; i++) {
                let li = document.createElement("li");
                li.className = "nav-item";
                if (i == 0) {
                    li.innerHTML = "<a class='nav-link active' id='home-tab' data-toggle='tab' title=" + tabs[i].tooltip + " data-name=" + tabs[i].name + " href=#" + tabs[i].name + " role = 'tab' aria-controls=" + tabs[i].fieldid + " aria-selected='true'>" + tabs[i].name + "</a>";
                } else {
                    li.innerHTML = "<a class='nav-link' id='home-tab' data-toggle='tab' title=" + tabs[i].tooltip + " href=#" + tabs[i].name + " data-name=" + tabs[i].name + " role = 'tab' aria-controls=" + tabs[i].fieldid + " aria-selected='false'>" + tabs[i].name + "</a>";
                }
                navtabs.appendChild(li);
            }
            rowdetail.appendChild(navtabs);
            // Tab Content
            let tabspane = document.createElement("div");
            tabspane.className = "tab-pane fade show active";
            tabspane.setAttribute("role", "tabpanel");
            tabspane.id = "tabPartialView";
            tabspane.setAttribute("aria-labelledby", "home-tab")
            rowdetail.append(tabspane)
        }
    }


}(jQuery))

