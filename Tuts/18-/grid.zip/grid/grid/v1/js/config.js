﻿var tabsType =
{
    normal: 1,
    accordion: 2
}


function adekTableAccordion(rootelement, accordion, accordionParams) {
    if (accordion != undefined) {
        let Accordiancontent = document.createElement("div");
        Accordiancontent.className = "accordion";
        Accordiancontent.id = "adekTableAccordion";

        rootelement.append(Accordiancontent);

        let tabspane = document.createElement("div");
        tabspane.className = "tab-pane fade show active";
        tabspane.setAttribute("role", "tabpanel");
        tabspane.id = "tabPartialView";
        tabspane.setAttribute("aria-labelledby", "home-tab")
        Accordiancontent.appendChild(tabspane)
        let tblaccordion = document.createElement("div");
        tblaccordion.className = "accordion";
        tblaccordion.id = "adekTableAccordion";

        tabspane.appendChild(tblaccordion)
        for (var i = 0; i < accordion.length; i++) {
            let card = document.createElement("div");
            card.className = "card";
            tblaccordion.append(card);

            let cardheader = document.createElement("div");
            cardheader.innerHTML = "<h6 class='mb-0'>" + accordion[i].heading + "</h6><button class='btn btn-link' type='button' data-toggle='collapse' data-target='#collapse" + i + "' aria-expanded='true' aria-controls='collapse" + i + "'><i class='fa fa-arrow-circle-down'></i></button>";
            cardheader.className = "card-header";
            cardheader.id = "heading" + i;
            card.appendChild(cardheader);

            let div = document.createElement("div");
            if (i == 0) {
                div.className = "collapse show";
            }
            else {
                div.className = "collapse";
            }
            div.setAttribute("aria-labelledby", "heading" + i);
            div.setAttribute("data-parent", "#adekTableAccordion");
            div.id = "collapse" + i;
            card.appendChild(div);
            //content view URL data bind to card body Todo

            let cardbody = document.createElement("div");
            cardbody.className = "card-body";
            cardbody.id = "cardbodyData" + i;
            div.append(cardbody);
            var param = "";
            if (accordionParams != undefined) {
                param = accordionParams.find(x => x.id == accordion[i].accordionid).contentViewParams;
            }
            rootelement.find("#cardbodyData" + i).empty().load(accordion[i].contentViewUrl + param);
        }
    }
}

function adekTableDataColumn(tableBody, config, pageNumber, pageSize, sortColumns, sortOrder, searchInput) {
    let tableContainerrowCol = tableBody.find("#mainDiv");
    var columns = config.columns;
    if (!config.enableSorting || (config.dataField == undefined && config.sortOrder == undefined)) {
        config.dataField = "";
        config.sortOrder = "";
    }
    var pageNo = "";
    if (pageNumber == undefined || pageNumber == 0) {
        pageNo = config.paging.pageNumber;
    } else { pageNo = pageNumber }

    var _pageSize = "";
    if (pageSize == undefined || pageSize == 0) {
        _pageSize = config.paging.pageSize;
    } else { _pageSize = pageSize }

    var _sortColumns = "";
    if (sortColumns == undefined || sortColumns == 0) {
        _sortColumns = config.sortColumns;
    } else { _sortColumns = sortColumns }

    var _sortOrder = "";
    if (sortOrder == undefined || sortOrder == 0) {
        _sortOrder = "asc";
    } else { _sortOrder = sortOrder }

    var _searchInput = "";
    if (searchInput == undefined || searchInput == 0) {
        _searchInput = "";
    } else { _searchInput = searchInput }
    var UrlType = config.apiRootUrl.indexOf('?') > -1 ? "&" : "?";
    $.ajax({
        type: 'get',
        url: config.apiRootUrl + `${UrlType}pageNumber=${pageNo}&sortField=${_sortColumns}&sortOrder=${_sortOrder}&pageSize=${_pageSize}&searchInput=${_searchInput}`,
        success: function (data) {
            if (data == undefined || data.items.length == 0) {
                tableBody.find(".notfound").remove();
                tableBody.find(".row .adek-table-row").remove();
                tableBody.find(".pagination").remove();
                tableBody.find(".totalrecord").remove();
                let tablenotfoundrow = document.createElement("div");
                tablenotfoundrow.className = "notfound";
                tablenotfoundrow.innerHTML = "no record found";
                tableBody.find(".adek-table").append(tablenotfoundrow);
                return;
            }
            else {
                tableBody.find(".notfound").remove();
                tableBody.find(".row .adek-table-row").remove();
                tableBody.find(".pagination").remove();
                tableBody.find(".totalrecord").remove();
                for (var i = 0; i < data.items.length; i++) {
                    let tablerowadektablerow = document.createElement("div");
                    tablerowadektablerow.className = "row adek-table-row";
                    let tablerowadektablehead = document.createElement("div");
                    tableBody.find(".adek-table").append(tablerowadektablerow);
                    for (var j = 0; j < columns.length; j++) {
                        let col = document.createElement("div");
                        switch (columns[j].type) {
                            //case type.action:
                            //    col.className = columns[j].class + " actions";
                            //    if (columns[j].typeConf.length > 0) {
                            //        var actionlinks = "";
                            //        for (var k = 0; k < columns[j].typeConf.length; k++) {

                            //            if (columns[j].typeConf[k].iconImageUrl != undefined && columns[j].typeConf[k].iconImageUrl != '') {
                            //                var link = "<a title='" + columns[j].typeConf[k].tooltip + "' onclick='" + columns[j].typeConf[k].method + "' href='JavaScript:void(0);'><img class='" + columns[j].typeConf[k].iconClass + "' src='" + columns[j].typeConf[k].iconImageUrl + "' /></a>";
                            //            } else {
                            //                var link = "<a title='" + columns[j].typeConf[k].tooltip + "' onclick='" + columns[j].typeConf[k].method + "' href='JavaScript:void(0);'><i " + ((columns[j].typeConf[k].iconWidth != undefined && columns[j].typeConf[k].iconHeight != undefined) ? ("style='width: " + columns[j].typeConf[k].iconWidth + "px; height: " + columns[j].typeConf[k].iconHeight + "px;'") : "") + ((columns[j].typeConf[k].fontSize != undefined) ? ("font-size='" + columns[j].typeConf[k].fontSize + "'") : "") + "class='" + columns[j].typeConf[k].iconClass + "'></i></a>";
                            //            }

                            //            actionlinks = actionlinks + link;
                            //        }
                            //        col.innerHTML = actionlinks;
                            //    }
                            //break;
                            case type.action:
                                col.className = columns[j].class + " actions";
                                if (columns[j].typeConf.length > 0) {
                                    for (var k = 0; k < columns[j].typeConf.length; k++) {
                                        let actionlink = document.createElement("a");
                                        actionlink.title = columns[j].typeConf[k].tooltip;
                                        if ($.isFunction(columns[j].typeConf[k].method)) {
                                            console.log(columns[j].typeConf[k].method);
                                            actionlink.addEventListener("click", function() { 
                                                console.log(columns[j]);
                                                columns[j].typeConf[k].method.call(this, data.items[i]);
                                            },false);
                                        }
                                        //$(actionlink).bind("click", columns[j].typeConf[k].method);
                                        //actionlink.addEventListener("click", () => { columns[j].typeConf[k].method.call(this, data.items[i]); });
                                        //actionlink.addEventListener("click", function () { BindActionMethod(columns[j].typeConf[k].method, data.items[i]); return false;} );
                                        actionlink.href = "JavaScript:void(0);";
                                        if (columns[j].typeConf[k].iconImageUrl != undefined && columns[j].typeConf[k].iconImageUrl != '') {
                                            actionlink.innerHTML = "<img class='" + columns[j].typeConf[k].iconClass + "' src='" + columns[j].typeConf[k].iconImageUrl + "' />";
                                        } else {
                                            actionlink.innerHTML = "<i " + ((columns[j].typeConf[k].iconWidth != undefined && columns[j].typeConf[k].iconHeight != undefined) ? ("style='width: " + columns[j].typeConf[k].iconWidth + "px; height: " + columns[j].typeConf[k].iconHeight + "px;'") : "") + ((columns[j].typeConf[k].fontSize != undefined) ? ("font-size='" + columns[j].typeConf[k].fontSize + "'") : "") + "class='" + columns[j].typeConf[k].iconClass + "'></i>";
                                        }
                                        $(actionlink).appendTo(col);
                                    }
                                }
                                break;
                            case type.text:
                                col.className = columns[j].class;
                                col.setAttribute("data-dataField", columns[j].typeConf.dataField);
                                col.setAttribute("data-value", data.items[i][columns[j].typeConf.dataField]);
                                col.innerHTML = data.items[i][columns[j].typeConf.dataField];
                                if (columns[j].clickable == true)
                                    col.style.cursor = "pointer";
                                break;
                            case type.data:
                                col.className = columns[j].class;
                                let rowspacerdiv = document.createElement("div");
                                rowspacerdiv.className = "row spacers";
                                var rowspacers = "";
                                for (var l = 0; l < columns[j].typeConf.properties.length; l++) {
                                    rowspacers = rowspacers + "<div class='" + columns[j].typeConf.properties[l].class + "'>" + columns[j].typeConf.properties[l].dataField + "</div>"
                                }
                                $(rowspacers).appendTo(rowspacerdiv);
                                col.innerHTML = "<div class='row mb-2'><div class='col-md-auto'>" + columns[j].typeConf.numberField + "</div><div class='col-md-*'>" + columns[j].typeConf.headingField + "</div></div>";
                                $(rowspacerdiv).appendTo(col);
                                break;
                            case type.template:
                                col.innerHTML = BindTemplate(columns[j].typeConf.template, data.items[i]);
                                break;
                            default:
                                col.className = columns[j].class;
                                col.innerHTML = data.items[i][columns[j].typeConf.dataField];
                                break;
                        }
                        if (columns[j].IsHidden == true)
                            col.style.display = "none";
                        tablerowadektablerow.appendChild(col);
                        tablerowadektablerow.appendChild(col);

                    }
                    tablerowadektablerow.appendChild(tablerowadektablehead);
                }
                //PAGINATION
                adekTablePaging(tableBody, config, data);
            }
        }
    });
}

function BindTemplate(template, data) {
    if ($.isFunction(template)) {
        var tempHtml = template.call(this, data);
        return tempHtml;
    }
}

function adekTablePaging(tableBody, config, data) {
    let tableContainerrowCol = tableBody.find("#mainDiv");
    let tablePaginationrow = document.createElement("div");
    tablePaginationrow.className = "row totalrecord";
    $(tableContainerrowCol).append(tablePaginationrow);

    let tablePaginationrowCol = document.createElement("div");
    tablePaginationrowCol.className = "col-md-6";
    tablePaginationrowCol.innerHTML = "Showing " + data.index + " to " + data.size + " of " + data.count + " records";
    tablePaginationrow.appendChild(tablePaginationrowCol);

    let div = document.createElement("div");
    div.className = "col-md-6";

    tablePaginationrow.appendChild(div);
    let ul = document.createElement("ul");
    ul.className = "pagination";

    div.appendChild(ul);
    let li = document.createElement("li");
    if (data.hasPrevious == true) {
        let lifirst = document.createElement("li");
        lifirst.className = "page-item";
        lifirst.innerHTML = "   <a class='page-link' data-id=" + parseInt(1) + "  href='JavaScript:void(0);'>&lt;&lt;</a>"
        ul.append(lifirst);
        li.className = "page-item";
        li.innerHTML = "   <a class='page-link' data-id=" + parseInt(data.index - 1) + "  href='JavaScript:void(0);'>&lt;</a>"
        ul.append(li);
    }
    for (var i = 1; i <= data.pages; i++) {
        let li = document.createElement("li");
        li.className = "page-item";
        li.innerHTML = "   <a class='page-link' data-id=" + parseInt(i) + " href='JavaScript:void(0);'>" + i + "</a>";
        li.onclick = "alert('set')";
        ul.append(li)
    }
    if (data.hasNext == true) {
        li.className = "page-item";
        li.innerHTML = "   <a class='page-link' data-id=" + parseInt(data.index + 1) + "  href='JavaScript:void(0);'>&gt;</a>"
        ul.append(li);
        let lilast = document.createElement("li");
        lilast.className = "page-item";
        lilast.innerHTML = "   <a class='page-link' data-id=" + parseInt(data.pages) + " href='JavaScript:void(0);'>&gt;&gt;</a>"
        ul.append(lilast);
    }
    tableBody.find("a.page-link").click(function () {
        adekTableDataColumn(tableBody, config, $(this).attr("data-id"), 0, 0, 0, 0);
    });

    tableBody.find(".adek-table-row>div[class^='col-']").click(function () {
        if (config.tabs != undefined && $(this).attr("data-dataField") != undefined && config.columns.find(x => x.typeConf.dataField == $(this).attr("data-dataField")).clickable == true) {
            if ($(this).parent().find($(".row-detail")).length > 0) {
                $(this).parent().find($(".row-detail")).slideUp(500, function () {
                    $(this).remove();
                });
            }
            else {
                tableBody.find(".adek-table").find(".row-detail").remove();
                var rowDetailClone = $(".row-detail").clone();
                rowDetailClone.removeClass("d-none");
                rowDetailClone.appendTo($(this).parent()).hide();
                rowDetailClone.slideDown(500);
            }

            var tabconfig = config.tabs.find(x => x.fieldid == $("a.active").attr("aria-controls"));
            if (tabconfig != undefined && tabconfig.type == tabsType.normal) {
                tableBody.find(".adek-table").find("#tabPartialView").empty().load(tabconfig.contentViewUrl);
            } else {
                if (tabconfig.type == tabsType.accordion) {
                    tableBody.find(".adek-table").find("#tabPartialView").empty();
                    adekTableAccordion(tableBody.find(".adek-table").find("#tabPartialView"), tabconfig.AccordionConfiguration);
                }
            }

            tableBody.find(".adek-table").find(".nav-link").click(function () {
                var tabconfig = config.tabs.find(x => x.fieldid == $(this).attr("aria-controls"));
                var AddParams = "?";
                if (tabconfig.contentViewParams != undefined && tabconfig.contentViewParams.length > 0) {

                    for (var m = 0; m < tabconfig.contentViewParams.length; m++) {
                        var currentrow = $(this).parent().parent().parent().parent().children();
                        if (currentrow != undefined) {
                            $.each(currentrow, function (index, val) {
                                if ($(val).attr("data-datafield") == tabconfig.contentViewParams[m].datafield) {
                                    var value = $(val).attr("data-value");
                                    AddParams += tabconfig.contentViewParams[m].paramName + "=" + value + "&";
                                }
                            });
                        }
                    }
                    AddParams = AddParams.slice(0, -1);
                } else { AddParams = ""; }
                if (tabconfig != undefined && tabconfig.type == tabsType.normal) {
                    tableBody.find(".adek-table").find("#tabPartialView").empty().load(tabconfig.contentViewUrl + AddParams);
                } else {
                    if (tabconfig.type == tabsType.accordion) {
                        var AddAccordionParams = "?";
                        var arr = [];
                        if (tabconfig.AccordionConfiguration != undefined && tabconfig.AccordionConfiguration.length > 0) {
                            for (var m = 0; m < tabconfig.AccordionConfiguration.length; m++) {

                                for (var a = 0; a < tabconfig.AccordionConfiguration[m].contentViewParams.length; a++) {
                                    var currentrow = $(this).parent().parent().parent().parent().children();
                                    if (currentrow != undefined) {
                                        $.each(currentrow, function (index, val) {
                                            if ($(val).attr("data-datafield") == tabconfig.AccordionConfiguration[m].contentViewParams[a].datafield) {
                                                var value = $(val).attr("data-value");
                                                AddAccordionParams += tabconfig.AccordionConfiguration[m].contentViewParams[a].paramName + "=" + value + "&";
                                            }
                                        });
                                    }
                                }
                                var ParamObject = {};
                                var accId = tabconfig.AccordionConfiguration[m].accordionid;
                                AddAccordionParams = AddAccordionParams.slice(0, -1);
                                ParamObject.id = accId;
                                ParamObject.contentViewParams = AddAccordionParams;
                                arr.push(ParamObject);
                                AddAccordionParams = "?";
                            }
                        }
                        else { AddAccordionParams = ""; }
                        tableBody.find(".adek-table").find("#tabPartialView").empty();
                        adekTableAccordion(tableBody.find(".adek-table").find("#tabPartialView"), tabconfig.AccordionConfiguration, arr);
                    }
                }
            });
        }
    });
}

function BindActionMethod(method, data) {
    if ($.isFunction(method)) {
        method.call(this, data);
    }
}
